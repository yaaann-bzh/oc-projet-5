
-- --------------------------------------------------------

--
-- Structure de la table `jobs_recruiters`
--

DROP TABLE IF EXISTS `jobs_recruiters`;
CREATE TABLE IF NOT EXISTS `jobs_recruiters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `pass` varchar(255) COLLATE utf8_bin NOT NULL,
  `inscriptionDate` datetime NOT NULL,
  `deleteDate` datetime DEFAULT NULL,
  `connexionId` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `firm` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `jobs_recruiters`
--

INSERT INTO `jobs_recruiters` (`id`, `username`, `email`, `pass`, `inscriptionDate`, `deleteDate`, `connexionId`) VALUES
(1, 'Yaaann', 'yann.tachier@gmail.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', NULL, '5dcadfadcf26f6.08572381');
