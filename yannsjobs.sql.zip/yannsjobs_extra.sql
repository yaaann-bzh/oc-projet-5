
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `jobs_posts`
--
ALTER TABLE `jobs_posts`
  ADD CONSTRAINT `recruiters` FOREIGN KEY (`recruiterId`) REFERENCES `jobs_recruiters` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
