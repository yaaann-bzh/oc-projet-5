
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `jobs_candidacies`
--
ALTER TABLE `jobs_candidacies`
  ADD CONSTRAINT `candidate_on_candidacy` FOREIGN KEY (`candidateId`) REFERENCES `jobs_members` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `post_on_candidacy` FOREIGN KEY (`postId`) REFERENCES `jobs_posts` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `recruiter_on_candidacy` FOREIGN KEY (`recruiterId`) REFERENCES `jobs_members` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `jobs_posts`
--
ALTER TABLE `jobs_posts`
  ADD CONSTRAINT `recruiter_on_post` FOREIGN KEY (`recruiterId`) REFERENCES `jobs_members` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Contraintes pour la table `jobs_saved`
--
ALTER TABLE `jobs_saved`
  ADD CONSTRAINT `candidate_on_saved` FOREIGN KEY (`candidateId`) REFERENCES `jobs_members` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `post_on_saved` FOREIGN KEY (`postId`) REFERENCES `jobs_posts` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
