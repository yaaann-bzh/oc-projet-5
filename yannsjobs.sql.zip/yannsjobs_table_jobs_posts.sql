
-- --------------------------------------------------------

--
-- Structure de la table `jobs_posts`
--

DROP TABLE IF EXISTS `jobs_posts`;
CREATE TABLE IF NOT EXISTS `jobs_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firmId` int(11) NOT NULL,
  `location` varchar(50) COLLATE utf8_bin NOT NULL,
  `title` varchar(255) COLLATE utf8_bin NOT NULL,
  `content` text COLLATE utf8_bin NOT NULL,
  `addDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
