
-- --------------------------------------------------------

--
-- Structure de la table `jobs_saved`
--

DROP TABLE IF EXISTS `jobs_saved`;
CREATE TABLE IF NOT EXISTS `jobs_saved` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidateId` int(11) NOT NULL,
  `postId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `candidate_on_saved` (`candidateId`),
  KEY `post_on_saved` (`postId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
