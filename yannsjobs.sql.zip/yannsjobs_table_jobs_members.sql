
-- --------------------------------------------------------

--
-- Structure de la table `jobs_members`
--

DROP TABLE IF EXISTS `jobs_members`;
CREATE TABLE IF NOT EXISTS `jobs_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_bin NOT NULL,
  `role` varchar(10) COLLATE utf8_bin NOT NULL,
  `lastname` varchar(25) COLLATE utf8_bin NOT NULL,
  `firstname` varchar(25) COLLATE utf8_bin NOT NULL,
  `email` varchar(30) COLLATE utf8_bin NOT NULL,
  `pass` varchar(60) COLLATE utf8_bin NOT NULL,
  `inscriptionDate` datetime NOT NULL,
  `deleteDate` datetime DEFAULT NULL,
  `connexionId` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `firm` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `jobs_members`
--

INSERT INTO `jobs_members` (`id`, `username`, `role`, `lastname`, `firstname`, `email`, `pass`, `inscriptionDate`, `deleteDate`, `connexionId`) VALUES
(1, 'Yaaann', 'recruiter', 'representant', 'representant', 'yann.tachier@gmail.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', NULL, '5dcf03867d48c7.01542241'),
(2, 'Yann', 'candidate', 'Tachier', 'Yann', 'y.tachier@gmail.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', NULL, ''),
(5, 'recruiter', 'recruiter', 'representant', 'representant', 'email@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', '2019-11-14 00:00:00', '5dced06708e6a8.42338160');
