
-- --------------------------------------------------------

--
-- Structure de la table `jobs_members`
--

DROP TABLE IF EXISTS `jobs_members`;
CREATE TABLE IF NOT EXISTS `jobs_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_bin NOT NULL,
  `role` varchar(10) COLLATE utf8_bin NOT NULL,
  `lastname` varchar(25) COLLATE utf8_bin NOT NULL,
  `firstname` varchar(25) COLLATE utf8_bin NOT NULL,
  `email` varchar(30) COLLATE utf8_bin NOT NULL,
  `phone` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `pass` varchar(60) COLLATE utf8_bin NOT NULL,
  `inscriptionDate` datetime NOT NULL,
  `deleteDate` datetime DEFAULT NULL,
  `connexionId` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `firm` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
