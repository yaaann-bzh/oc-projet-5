
-- --------------------------------------------------------

--
-- Structure de la table `jobs_members`
--

DROP TABLE IF EXISTS `jobs_members`;
CREATE TABLE IF NOT EXISTS `jobs_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) COLLATE utf8_bin NOT NULL,
  `role` varchar(10) COLLATE utf8_bin NOT NULL,
  `lastname` varchar(25) COLLATE utf8_bin NOT NULL,
  `firstname` varchar(25) COLLATE utf8_bin NOT NULL,
  `email` varchar(30) COLLATE utf8_bin NOT NULL,
  `pass` varchar(60) COLLATE utf8_bin NOT NULL,
  `inscriptionDate` datetime NOT NULL,
  `deleteDate` datetime DEFAULT NULL,
  `connexionId` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `savedPosts` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `firm` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `jobs_members`
--

INSERT INTO `jobs_members` (`id`, `username`, `role`, `lastname`, `firstname`, `email`, `pass`, `inscriptionDate`, `deleteDate`, `connexionId`, `savedPosts`) VALUES
(1, 'Yaaann', 'recruiter', 'representant', 'representant', 'yann.tachier@gmail.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', NULL, '5dd3011ebaf322.99333798', NULL),
(2, 'Yann', 'candidate', 'Tachier', 'Yann', 'y.tachier@gmail.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', NULL, '5dd3a77ce5b690.02427809', '3,12,9'),
(3, 'Entreprise 1', 'recruiter', 'representant', 'representant', 'email1@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-10-04 00:00:01', NULL, '5dd304cfe63da2.67108287', NULL),
(4, 'Entreprise 2', 'recruiter', 'representant', 'representant', 'email2@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-06-04 00:00:02', NULL, NULL, NULL),
(5, 'Entreprise 3', 'recruiter', 'representant', 'representant', 'email3@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-08-04 00:00:03', NULL, NULL, NULL),
(6, 'Entreprise 4', 'recruiter', 'representant', 'representant', 'email4@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-09-25 00:00:04', NULL, NULL, NULL),
(7, 'Entreprise 5', 'recruiter', 'representant', 'representant', 'email5@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-01 00:00:05', NULL, NULL, NULL),
(8, 'Entreprise 6', 'recruiter', 'representant', 'representant', 'email6@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-10-22 00:00:06', NULL, NULL, NULL),
(9, 'Entreprise 7', 'recruiter', 'representant', 'representant', 'email@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-08-12 00:00:00', NULL, NULL, NULL),
(10, 'Candidat 1', 'candidate', 'Nom', 'Prenom', 'email7@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', NULL, NULL, NULL),
(11, 'Candidat 2', 'candidate', 'Tachier', 'Prenom', 'email8@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', NULL, NULL, NULL),
(12, 'Candidat 3', 'candidate', 'Tachier', 'Prenom', 'email9@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', NULL, NULL, NULL),
(13, 'Candidat 4', 'candidate', 'Tachier', 'Prenom', 'email10@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', NULL, NULL, NULL),
(14, 'Candidat 5', 'candidate', 'Tachier', 'Prenom', 'email11@domaine.com', '$2y$10$OZQi8Nzbm/bELDBTDH1LfuJRSLYV.2E1lZHGu897AgWJ684UX84VC', '2019-11-04 00:00:00', NULL, NULL, NULL);
