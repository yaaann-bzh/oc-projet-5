
-- --------------------------------------------------------

--
-- Structure de la table `jobs_candidacies`
--

DROP TABLE IF EXISTS `jobs_candidacies`;
CREATE TABLE IF NOT EXISTS `jobs_candidacies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `candidateId` int(11) NOT NULL,
  `postId` int(11) NOT NULL,
  `recruiterId` int(11) NOT NULL,
  `cover` text COLLATE utf8_bin NOT NULL,
  `resumeFile` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `sendDate` datetime NOT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `isArchived` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `post_on_candidacy` (`postId`),
  KEY `recruiter_on_candidacy` (`recruiterId`),
  KEY `candidate_on_candidacy` (`candidateId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
